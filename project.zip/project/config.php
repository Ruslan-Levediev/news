<?php
return [
    'base_url' => '/project/public',
];
